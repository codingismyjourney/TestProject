﻿namespace LinkedInWebApp.Models;

public class Post
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Images { get; set; }
    public string Comment { get; set; }
    public DateTime CreatedOn { get; set; }
    public DateTime ModifiedOn { get; set; }
}
