﻿using Microsoft.AspNetCore.Identity;

namespace LinkedInWebApp.Models;

public class AppUserRole : IdentityUserRole<int>
{
}
