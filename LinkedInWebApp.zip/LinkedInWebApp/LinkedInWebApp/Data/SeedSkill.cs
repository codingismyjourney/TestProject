﻿using LinkedInWebApp.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace LinkedInWebApp.Data;

public static class SeedSkill
{
    public static async Task SeedSkills(DataContext context)
    {
        if (await context.Skills.AnyAsync()) return;

        var skills = new List<Skill>
        {
            new Skill{Name = "Asp.Net Core"},
            new Skill{Name = "Javascript"},
            new Skill{Name = "C#"},
            new Skill{Name = "TypeScript"},
            new Skill{Name = "Angular"},
        };

        await context.Skills.AddRangeAsync(skills);
        await context.SaveChangesAsync();  
    }
}
