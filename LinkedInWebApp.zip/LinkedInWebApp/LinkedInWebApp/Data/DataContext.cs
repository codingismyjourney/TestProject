﻿using LinkedInWebApp.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace LinkedInWebApp.Data;

public class DataContext : IdentityDbContext<AppUser, AppRole, int,
        IdentityUserClaim<int>, AppUserRole, IdentityUserLogin<int>,
        IdentityRoleClaim<int>, IdentityUserToken<int>>
{
    public DataContext(DbContextOptions options) : base(options)
    {
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<PostLike>()
            .HasKey(pl => new { pl.AppUserId, pl.PostId });

        modelBuilder.Entity<UserSkill>()
            .HasKey(pl => new { pl.AppUserId, pl.SkillId });
    }


    public DbSet<Post> Posts { get; set; }
    public DbSet<Skill> Skills { get; set; }
    public DbSet<PostLike> PostLikes { get; set; }
    public DbSet<UserSkill> UserSkills { get; set; }
}
